import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showauthor',
  templateUrl: './showauthor.component.html',
  styleUrls: ['./showauthor.component.css']
})
export class ShowauthorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
